import java.util.Objects;

public class persona {
    
    public String nombre;
    public int identificacion;
    public String direccion;
    public int telefono;

    public persona(String nombre, int identificacion, String direccion, int telefono) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.direccion = direccion;
        this.telefono = telefono;
    }

  public String toString()
  {
      return "Nombre= " + nombre + "\n\tIdentificación= " + identificacion + "\n\tDirección= " + direccion + "\n\tTeléfono= " + telefono ;
  }

    public String getnombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getidentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getTelefono() {
        return telefono;
    }

    public void settelefono(int telefono) {
        this.telefono = telefono;
    }

}