public class Proveedor extends persona {
     
    private String direccionpersona;

    public Proveedor(String nombre, int identificacion, String direccion, int telefono) {
        super(nombre, identificacion, direccion, telefono);
        this.Proveedor =  Producto; 
    }
  

    @Override
   public String toString()
   {
      return"\tpersona - " + super.toString() + "\n\tdireccion persona: " + direccionpersona + "\n";
   }
}