import java.util.Scanner;
import java.util.ArrayList;



public class Gestion {



    public static void main(String[] args) {

        Gestion gestion_1 = new Gestion();
        gestion_1.procesarComandos();
    }
    
    private ArrayList<persona> listapersona = new ArrayList<>();
    
    public Gestion(){
    
     }
    
    public  void procesarComandos()
    {
        String[] parametros;
        Socio socio_1;
        Proveedor proveedor_1;
        Scanner opcion = new Scanner(System.in);
        boolean siga = true;
      
        System.out.println("Menu Pricipal \n 1. Agregar persona \n 2. Listar persona");
        String comando = opcion.nextLine();
     do{
        
        parametros = comando.split("&");
        if(parametros[0].equals("1") )
        {
           if (parametros[1].equals("Proveedor") || parametros[1].equals("proveedor"))
             {    
                proveedor_1 = new Proveedor(Integer.toString(parametros[2]), Integer(Parametros[3]),String(parametros[4]),(parametros[5]);
                this.agregarGestion(proveedor_1);
             }
        
           if( parametros[1].equals("Socio") || parametros[1].equals("socio"))
             {
                socio_1 = new Socio(Integer.toString(parametros[2]),Integer(parametros[3]),String(parametros[4]),(parametros[5]);

                this.agregarGestion(socio_1);
             }
           else
           {
               System.out.println("Usted ha digitado mal el nobre de la persona no valido.");
           }
           comando = opcion.nextLine();
           if(comando.equals("3"))
            {
                System.exit(0);
            }
        }
        else if(parametros[0].equals("2"))
        {
            System.out.println("***Listado de personas***");
            ArrayList<persona> listapersonas = null;
            this.listarGestion(listapersonas);
            
            comando = opcion.nextLine();
            if(comando.equals("3"))
            {
                System.exit(0);
            }
        }
        
        
       }while(siga == true);
    }
    
    public void agregarGestion(persona  Persona)
    {
       listapersona.add(Persona);
    }
    
    
    public void agregarGestion(Socio socio)
    {
       listapersona.add(socio);
    }
    
    public void listarGestion(ArrayList<persona> listaGestion)
    {
    
        for(int i = 0; i < listaGestion.size()  ; i++)
            {
                if(listaGestion.get(i).getClass() == Proveedor.class)
                {
                    Proveedor proveedor = (Proveedor)listaGestion.get(i);
                    System.out.println(proveedor.toString());
                    
                }
                else if(listaGestion.get(i).getClass() == Socio.class)
                {
                    Socio socio = (Socio) listaGestion.get(i);
                    System.out.println(socio.toString());
                }
            }
    }
}