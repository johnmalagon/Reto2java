public class Socio  extends persona {
  
    private String direccionSocio;
    
public Socio(String nombre, int identificacion, String direccion, int telefono) {
        super(nombre, identificacion, direccion, telefono);
        this.direccionSocio = antiguedadSocio ;
}
    @Override
    public String toString()
        {
          return "\tSocio - " + super.toString() + "\n\tdireccion Socio: " + direccionSocio + "\n";
        }
    
   
}